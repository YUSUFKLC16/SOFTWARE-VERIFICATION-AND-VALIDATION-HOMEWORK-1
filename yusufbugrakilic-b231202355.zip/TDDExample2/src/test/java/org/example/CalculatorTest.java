///
///B231202355
///YUSUF BUĞRA KILIÇ
///Software Verification and Validation homework-1
///My github URL adress is: https://github.com/YUSUFKLC16/SOFTWARE-VERIFICATION-AND-VALIDATION-HOMEWORK-1.git

package org.example;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.junit.jupiter.api.Assertions.*;

class CalculatorTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void testDivision1() {
        assertEquals(5, Calculator.divide(10, 2));
    }

    @Test
    void testDivision2() {
        assertEquals(2.5, Calculator.divide(10, 4));
    }

    @Test
    void testDivision3() {
        assertEquals(5, Calculator.divide(12.5f, 2.5f));
    }

    @Test
    void testDivision4() {
        assertEquals(4, Calculator.divide(10, 2.5f));
    }

    @Test
    void testDivision5() {
        assertEquals(2.5f, Calculator.divide(12.5f, 5));
    }
enum Values {
        testDivision1(10f, 2f, 5f),
        testDivision2(10f, 4f, 2.5f),
        testDivision3(12.5f, 2.5f, 5),
        testDivision4(10f, 2.5f, 4),
        testDivision5(12.5f, 5f, 2.5f);

         final float dividend,divisor,expectedResult;

        Values(float dividend, float divisor, float expectedResult) {
            this.dividend = dividend;
            this.divisor = divisor;
            this.expectedResult = expectedResult;
        }
    }
@ParameterizedTest
    @EnumSource(Values.class)
    void testDivision(Values testResultValue) {
        assertEquals(testResultValue.expectedResult, Calculator.divide(testResultValue.dividend, testResultValue.divisor));
    }


    @Test
    void testDivision6() {
        Exception exception = assertThrows(
                IllegalArgumentException.class,
                () -> Calculator.divide(12.5f, 0),
                "IllegalArgumentException expected."
        );

        // Optional. To check whether the error messages match.
        assertEquals("Illegal Argument Exception.", exception.getMessage());
    }
}