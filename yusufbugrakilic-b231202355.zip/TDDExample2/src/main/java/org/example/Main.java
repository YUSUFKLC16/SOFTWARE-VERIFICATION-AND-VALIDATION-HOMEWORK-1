package org.example;

public class Main {
    public static void main(String[] args) {
        float result = Calculator.divide(10, 0);
        System.out.println(result);
    }
}